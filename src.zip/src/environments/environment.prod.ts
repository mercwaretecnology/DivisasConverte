export const environment = {
  production: true,
  api_url: 'https://dog.ceo/api/breeds/list/all'
};
